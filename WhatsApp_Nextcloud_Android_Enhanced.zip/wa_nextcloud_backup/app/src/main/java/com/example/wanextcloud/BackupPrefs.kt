package com.example.wanextcloud

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object BackupPrefs {
    private fun prefs(c: Context) = EncryptedSharedPreferences.create(
        c, "backup_settings", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun server(c: Context) = prefs(c).getString("server", "") ?: ""
    fun username(c: Context) = prefs(c).getString("username", "") ?: ""
    fun password(c: Context) = prefs(c).getString("password", "") ?: ""
    fun remotePath(c: Context) = prefs(c).getString("remote", "Backups/WhatsApp") ?: "Backups/WhatsApp"
    fun folder(c: Context) = prefs(c).getString("folder", null)
    fun intervalHours(c: Context) = prefs(c).getInt("hours", 6)
    fun wifiOnly(c: Context) = prefs(c).getBoolean("wifi", true)
    fun encryptionEnabled(c: Context) = prefs(c).getBoolean("encrypt", false)
    fun encryptionPassword(c: Context) = prefs(c).getString("encryption_password", "") ?: ""
    fun lastSuccess(c: Context) = prefs(c).getString("last_success", "") ?: ""
    fun lastCount(c: Context) = prefs(c).getInt("last_count", 0)
    fun lastError(c: Context) = prefs(c).getString("last_error", "") ?: ""
    fun restoreStatus(c: Context) = prefs(c).getString("restore_status", "") ?: ""
    fun setRestoreStatus(c: Context, status: String) { prefs(c).edit().putString("restore_status", status.take(500)).apply() }
    fun saveFolder(c: Context, uri: String) { prefs(c).edit().putString("folder", uri).apply() }
    fun setLastSuccess(c: Context, stamp: String, count: Int) { prefs(c).edit().putString("last_success", stamp).putInt("last_count", count).putString("last_error", "").apply() }
    fun setLastError(c: Context, error: String) { prefs(c).edit().putString("last_error", error.take(300)).apply() }
    fun save(c: Context, server: String, username: String, password: String, remote: String, folder: String, hours: Int, wifi: Boolean, encrypt: Boolean, encryptionPassword: String) {
        prefs(c).edit().putString("server", server).putString("username", username).putString("password", password)
            .putString("remote", remote).putString("folder", folder).putInt("hours", hours)
            .putBoolean("wifi", wifi).putBoolean("encrypt", encrypt).putString("encryption_password", encryptionPassword).apply()
    }
}
