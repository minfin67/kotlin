package com.example.wanextcloud

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            BackupPrefs.saveFolder(this, it.toString())
        }
    }

    private val restoreFolderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            restoreDestination = it.toString()
        }
    }
    private var restoreDestination by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var server by remember { mutableStateOf(BackupPrefs.server(this)) }
            var username by remember { mutableStateOf(BackupPrefs.username(this)) }
            var password by remember { mutableStateOf(BackupPrefs.password(this)) }
            var remotePath by remember { mutableStateOf(BackupPrefs.remotePath(this)) }
            var hours by remember { mutableStateOf(BackupPrefs.intervalHours(this).toString()) }
            var folder by remember { mutableStateOf(BackupPrefs.folder(this).orEmpty()) }
            var wifiOnly by remember { mutableStateOf(BackupPrefs.wifiOnly(this)) }
            var encrypt by remember { mutableStateOf(BackupPrefs.encryptionEnabled(this)) }
            var encryptionPassword by remember { mutableStateOf(BackupPrefs.encryptionPassword(this)) }
            var savedMessage by remember { mutableStateOf("") }
            var snapshotName by remember { mutableStateOf("") }
            var restorePassword by remember { mutableStateOf(encryptionPassword) }
            var restoreStatus by remember { mutableStateOf(BackupPrefs.restoreStatus(this)) }
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("WhatsApp → Nextcloud", style = MaterialTheme.typography.headlineMedium)
                        Text("Private, automatic snapshots of your WhatsApp folder", style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider()
                        Text("Nextcloud connection", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(server, { server = it }, label = { Text("Nextcloud address (HTTPS)") }, placeholder = { Text("https://cloud.example.com") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(username, { username = it }, label = { Text("Nextcloud username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(password, { password = it }, label = { Text("Nextcloud app password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(remotePath, { remotePath = it }, label = { Text("Remote folder") }, placeholder = { Text("Backups/WhatsApp") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Text("Use a dedicated Nextcloud app password. The app stores credentials encrypted on this device.", style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider()
                        Text("WhatsApp source", style = MaterialTheme.typography.titleMedium)
                        Button(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Text(if (folder.isBlank()) "Select WhatsApp folder" else "Change selected folder") }
                        Text(if (folder.isBlank()) "Folder access not selected" else "Folder access granted (check that Databases and Media are included)", style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider()
                        Text("Schedule", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(hours, { hours = it.filter(Char::isDigit).take(2) }, label = { Text("Interval (hours, 1–24)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row { Checkbox(wifiOnly, { wifiOnly = it }); Column { Text("Wi-Fi only"); Text("Wait for an unmetered network", style = MaterialTheme.typography.bodySmall) } }
                        HorizontalDivider()
                        Text("Encryption", style = MaterialTheme.typography.titleMedium)
                        Row { Checkbox(encrypt, { encrypt = it }); Column { Text("Encrypt files before upload"); Text("AES-256-GCM; password is required to decrypt later", style = MaterialTheme.typography.bodySmall) } }
                        if (encrypt) {
                            OutlinedTextField(encryptionPassword, { encryptionPassword = it }, label = { Text("Backup encryption password (12+ characters)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                            Text("IMPORTANT: Keep this password safe. Without it, encrypted backups cannot be recovered.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = {
                            val interval = hours.toIntOrNull()?.coerceIn(1, 24) ?: 6
                            saveAll(server, username, password, remotePath, folder, interval, wifiOnly, encrypt, encryptionPassword)
                            BackupScheduler.schedule(this@MainActivity, interval)
                            savedMessage = "Automatic backup enabled (every $interval hour(s))."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save & enable automatic backup") }
                        OutlinedButton(onClick = {
                            saveAll(server, username, password, remotePath, folder, hours.toIntOrNull()?.coerceIn(1, 24) ?: 6, wifiOnly, encrypt, encryptionPassword)
                            val constraints = Constraints.Builder().setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).build()
                            val req = OneTimeWorkRequestBuilder<BackupWorker>().setConstraints(constraints).build()
                            WorkManager.getInstance(this@MainActivity).enqueue(req)
                            savedMessage = "Backup queued. It will start when network conditions are met."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Back up now") }
                        OutlinedButton(onClick = { BackupScheduler.cancel(this@MainActivity); savedMessage = "Automatic schedule cancelled." }, modifier = Modifier.fillMaxWidth()) { Text("Disable automatic backup") }
                        if (savedMessage.isNotBlank()) Text(savedMessage, color = MaterialTheme.colorScheme.primary)
                        HorizontalDivider()
                        Text("Backup status", style = MaterialTheme.typography.titleMedium)
                        Text("Last success: ${BackupPrefs.lastSuccess(this).ifBlank { "Not yet" }}")
                        Text("Files uploaded: ${BackupPrefs.lastCount(this)}")
                        val err = BackupPrefs.lastError(this)
                        if (err.isNotBlank()) Text("Last error: $err", color = MaterialTheme.colorScheme.error)
                        Text("Each run creates a timestamped folder on Nextcloud. Existing snapshots are not overwritten.", style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider()
                        Text("Restore from Nextcloud", style = MaterialTheme.typography.titleLarge)
                        Text("Enter the snapshot folder name exactly as it appears inside your remote backup folder.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(snapshotName, { snapshotName = it }, label = { Text("Snapshot name") }, placeholder = { Text("snapshot_2026-11-17_22-00-00") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = { restoreFolderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Text(if (restoreDestination.isBlank()) "Choose restore destination" else "Change restore destination") }
                        Text(if (restoreDestination.isBlank()) "Destination not selected" else "Restore destination selected", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(restorePassword, { restorePassword = it }, label = { Text("Backup encryption password (if encrypted)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Text("Restore copies files into the selected folder and overwrites same-named files. It does not delete other files. Back up your current WhatsApp folder before restoring.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            if (snapshotName.isBlank() || restoreDestination.isBlank()) { restoreStatus = "Enter a snapshot name and choose a destination." }
                            else {
                                saveAll(server, username, password, remotePath, folder, hours.toIntOrNull()?.coerceIn(1, 24) ?: 6, wifiOnly, encrypt, encryptionPassword)
                                val data = androidx.work.workDataOf("snapshot" to snapshotName.trim(), "destination" to restoreDestination, "encryption_password" to restorePassword)
                                val request = OneTimeWorkRequestBuilder<RestoreWorker>().setInputData(data).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
                                WorkManager.getInstance(this@MainActivity).enqueue(request)
                                restoreStatus = "Restore queued. Check status after it finishes."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Restore selected snapshot") }
                        if (restoreStatus.isNotBlank()) Text(restoreStatus, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    private fun saveAll(server: String, username: String, password: String, remote: String, folder: String, hours: Int, wifi: Boolean, encrypt: Boolean, encryptionPassword: String) {
        BackupPrefs.save(this, server.trim().trimEnd('/'), username.trim(), password, remote.trim(), folder, hours, wifi, encrypt, encryptionPassword)
    }
}
