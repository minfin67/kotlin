package com.example.wanextcloud

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object BackupScheduler {
    fun schedule(context: Context, hours: Int) {
        val constraints = Constraints.Builder().setRequiredNetworkType(if (BackupPrefs.wifiOnly(context)) NetworkType.UNMETERED else NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<BackupWorker>(hours.coerceIn(1, 24).toLong(), TimeUnit.HOURS)
            .setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("whatsapp_nextcloud_backup", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    fun cancel(context: Context) = WorkManager.getInstance(context).cancelUniqueWork("whatsapp_nextcloud_backup")
}
