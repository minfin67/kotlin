package com.example.wanextcloud

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.Worker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Restores one snapshot into a user-selected SAF folder. It never deletes destination files. */
class RestoreWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    private val http = OkHttpClient.Builder().connectTimeout(45, TimeUnit.SECONDS).readTimeout(10, TimeUnit.MINUTES).build()
    override fun doWork(): Result {
        val server = BackupPrefs.server(applicationContext).trim().trimEnd('/')
        val user = BackupPrefs.username(applicationContext).trim()
        val pass = BackupPrefs.password(applicationContext)
        val remoteRoot = BackupPrefs.remotePath(applicationContext).trim('/').split('/').filter(String::isNotBlank)
        val snapshot = inputData.getString("snapshot")?.trim()?.trim('/') ?: return Result.failure()
        val destinationUri = inputData.getString("destination")?.let(Uri::parse) ?: return Result.failure()
        val encryptionPassword = inputData.getString("encryption_password") ?: ""
        if (server.isBlank() || user.isBlank() || pass.isBlank() || remoteRoot.isEmpty() || snapshot.isBlank()) return Result.failure()
        return try {
            var base = "$server/remote.php/dav/files/${Uri.encode(user)}/"
            remoteRoot.forEach { base += Uri.encode(it) + "/" }
            val snapshotUrl = base + Uri.encode(snapshot) + "/"
            val destination = DocumentFile.fromTreeUri(applicationContext, destinationUri) ?: error("Destination folder unavailable")
            val saltHex = downloadText(snapshotUrl + "salt.txt", user, pass).trim()
            val salt = if (saltHex.isNotBlank()) hexToBytes(saltHex) else null
            val key = if (salt != null) {
                if (encryptionPassword.length < 12) error("This snapshot is encrypted. Enter the backup password.")
                deriveKey(encryptionPassword, salt)
            } else null
            val entries = listRecursively(snapshotUrl, user, pass)
            var restored = 0
            for (entry in entries) {
                if (entry.path == "salt.txt" || entry.path == "manifest.tsv" || entry.path == "manifest.tsv.enc") continue
                val pathParts = entry.path.split('/').filter { it.isNotBlank() }
                if (pathParts.isEmpty()) continue
                var parent = destination
                pathParts.dropLast(1).forEach { segment ->
                    parent = parent.findFile(segment)?.takeIf { it.isDirectory } ?: parent.createDirectory(segment) ?: error("Cannot create folder $segment")
                }
                val remoteFileName = pathParts.last()
                val encrypted = remoteFileName.endsWith(".waenc")
                val outputName = if (encrypted) remoteFileName.removeSuffix(".waenc") else remoteFileName
                val temp = File(applicationContext.cacheDir, "restore_${System.nanoTime()}.tmp")
                downloadToFile(snapshotUrl + entry.path.split('/').joinToString("/") { Uri.encode(it) }, temp, user, pass)
                val plain = if (encrypted) {
                    val activeKey = key ?: error("Encrypted file found but encryption password is missing")
                    val aadPath = pathParts.joinToString("/").removeSuffix(".waenc")
                    decryptFile(temp, activeKey, aadPath, File(applicationContext.cacheDir, "plain_${System.nanoTime()}.tmp"))
                } else temp
                val existing = parent.findFile(outputName)
                val target = if (existing?.isFile == true) existing else parent.createFile("application/octet-stream", outputName)
                    ?: error("Cannot create file $outputName")
                applicationContext.contentResolver.openOutputStream(target.uri, "wt")?.use { out -> FileInputStream(plain).use { it.copyTo(out) } }
                    ?: error("Cannot write destination file $outputName")
                temp.delete(); if (plain != temp) plain.delete(); restored++
            }
            BackupPrefs.setRestoreStatus(applicationContext, "Restore completed: $restored files from $snapshot")
            Result.success()
        } catch (e: Exception) {
            BackupPrefs.setRestoreStatus(applicationContext, "Restore failed: ${e.message ?: e.javaClass.simpleName}")
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }
    private data class Entry(val path: String, val directory: Boolean)
    private fun listRecursively(url: String, user: String, pass: String): List<Entry> {
        val result = mutableListOf<Entry>()
        fun visit(folderUrl: String, rel: String) {
            val xml = """<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/></d:prop></d:propfind>"""
            val req = Request.Builder().url(folderUrl).method("PROPFIND", okhttp3.RequestBody.create("application/xml".toMediaType(), xml)).header("Authorization", auth(user, pass)).header("Depth", "1").build()
            http.newCall(req).execute().use { response ->
                if (response.code != 207 && !response.isSuccessful) error("List snapshot failed: HTTP ${response.code}")
                val body = response.body?.string().orEmpty()
                val hrefs = Regex("<[^>]*href[^>]*>(.*?)</[^>]*href>", RegexOption.IGNORE_CASE).findAll(body).map { it.groupValues[1] }.toList()
                for (href in hrefs) {
                    val clean = href.substringBefore("?").trimEnd('/')
                    val folderClean = folderUrl.substringBefore("?").trimEnd('/')
                    if (clean == folderClean) continue
                    val raw = clean.substringAfterLast('/')
                    val name = URLDecoder.decode(raw.replace("+", "%2B"), "UTF-8")
                    if (name.isBlank()) continue
                    val isDir = Regex("<[^>]*collection\\s*/?>", RegexOption.IGNORE_CASE).containsMatchIn(body.substringAfter(href).substringBefore("</d:response>"))
                    val path = if (rel.isBlank()) name else "$rel/$name"
                    if (isDir) visit(folderUrl + Uri.encode(name) + "/", path) else result += Entry(path, false)
                }
            }
        }
        visit(url, "")
        return result
    }
    private fun downloadText(url: String, user: String, pass: String): String = http.newCall(Request.Builder().url(url).header("Authorization", auth(user, pass)).build()).execute().use { if (!it.isSuccessful) "" else it.body?.string().orEmpty() }
    private fun downloadToFile(url: String, file: File, user: String, pass: String) { http.newCall(Request.Builder().url(url).header("Authorization", auth(user, pass)).build()).execute().use { r -> if (!r.isSuccessful) error("Download failed HTTP ${r.code}"); r.body?.byteStream()?.use { input -> FileOutputStream(file).use { input.copyTo(it) } } ?: error("Empty download") } }
    private fun deriveKey(password: String, salt: ByteArray): ByteArray { val spec = javax.crypto.spec.PBEKeySpec(password.toCharArray(), salt, 210_000, 256); return javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
    private fun decryptFile(input: File, key: ByteArray, aad: String, output: File): File {
        FileInputStream(input).use { stream ->
            val header = ByteArray(17); if (stream.read(header) != header.size || String(header, 0, 5, Charsets.US_ASCII) != "WANC1") error("Unknown encrypted backup format")
            val iv = header.copyOfRange(5, 17)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv)); cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
            javax.crypto.CipherInputStream(stream, cipher).use { encrypted -> FileOutputStream(output).use { encrypted.copyTo(it) } }
        }
        return output
    }
    private fun hexToBytes(s: String): ByteArray { require(s.length % 2 == 0); return s.chunked(2).map { it.toInt(16).toByte() }.toByteArray() }
    private fun auth(user: String, pass: String) = "Basic " + android.util.Base64.encodeToString("$user:$pass".toByteArray(), android.util.Base64.NO_WRAP)
}
