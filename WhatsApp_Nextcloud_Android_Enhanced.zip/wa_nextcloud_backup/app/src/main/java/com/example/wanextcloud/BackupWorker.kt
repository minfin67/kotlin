package com.example.wanextcloud

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.Worker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.MediaType.Companion.toMediaType
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

class BackupWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    private val http = OkHttpClient.Builder().connectTimeout(45, TimeUnit.SECONDS).readTimeout(10, TimeUnit.MINUTES).writeTimeout(10, TimeUnit.MINUTES).build()

    override fun doWork(): Result {
        val treeUri = BackupPrefs.folder(applicationContext)?.let(Uri::parse) ?: return Result.failure()
        val server = BackupPrefs.server(applicationContext).trim().trimEnd('/')
        val user = BackupPrefs.username(applicationContext).trim()
        val pass = BackupPrefs.password(applicationContext)
        val remoteRoot = BackupPrefs.remotePath(applicationContext).trim('/').split('/').filter(String::isNotBlank)
        val encrypt = BackupPrefs.encryptionEnabled(applicationContext)
        val encryptionPassword = BackupPrefs.encryptionPassword(applicationContext)
        if (server.isBlank() || user.isBlank() || pass.isBlank() || remoteRoot.isEmpty()) return Result.failure()
        if (encrypt && encryptionPassword.length < 12) return Result.failure()
        return try {
            val base = "$server/remote.php/dav/files/${Uri.encode(user)}/"
            var rootUrl = base
            remoteRoot.forEach { segment -> rootUrl = ensureCollection(rootUrl + Uri.encode(segment) + "/", user, pass) }
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val snapshotUrl = ensureCollection(rootUrl + "snapshot_$stamp/", user, pass)
            val root = DocumentFile.fromTreeUri(applicationContext, treeUri) ?: throw Exception("Can't open selected folder permission")
            val records = mutableListOf<String>()
            val salt = ByteArray(16).also(SecureRandom()::nextBytes)
            val key = if (encrypt) deriveKey(encryptionPassword, salt) else null
            val count = uploadTree(root, snapshotUrl, "", user, pass, key, salt, records)
            val manifest = (listOf("WA-NEXTCLOUD-BACKUP\t1", "created\t$stamp", "encrypted\t$encrypt", "salt\t${salt.joinToString("") { "%02x".format(it.toInt() and 0xff) }}") + records).joinToString("\n")
            val manifestFile = File(applicationContext.cacheDir, "manifest_$stamp.tmp")
            manifestFile.writeText(manifest)
            val manifestUpload = if (encrypt && key != null) encryptFile(manifestFile, key, "manifest", File(applicationContext.cacheDir, "manifest_$stamp.enc")) else manifestFile
            putFile(snapshotUrl + if (encrypt) "manifest.tsv.enc" else "manifest.tsv", manifestUpload, user, pass, "text/plain")
            if (encrypt) putFile(snapshotUrl + "salt.txt", File(applicationContext.cacheDir, "salt_$stamp.txt").apply { writeText(salt.joinToString("") { "%02x".format(it.toInt() and 0xff) }) }, user, pass, "text/plain")
            manifestFile.delete(); if (manifestUpload != manifestFile) manifestUpload.delete()
            BackupPrefs.setLastSuccess(applicationContext, stamp, count)
            Result.success()
        } catch (e: Exception) {
            BackupPrefs.setLastError(applicationContext, e.message ?: e.javaClass.simpleName)
            if (runAttemptCount < 5) Result.retry() else Result.failure()
        }
    }

    private fun uploadTree(dir: DocumentFile, remote: String, relative: String, user: String, pass: String, key: ByteArray?, salt: ByteArray, records: MutableList<String>): Int {
        var uploaded = 0
        for (child in dir.listFiles()) {
            val name = child.name ?: "unnamed"
            val safeName = name.replace("/", "_")
            val rel = if (relative.isEmpty()) safeName else "$relative/$safeName"
            if (child.isDirectory) {
                val subUrl = ensureCollection(remote + Uri.encode(safeName) + "/", user, pass)
                uploaded += uploadTree(child, subUrl, rel, user, pass, key, salt, records)
            } else if (child.isFile) {
                val input = applicationContext.contentResolver.openInputStream(child.uri) ?: continue
                val temp = File(applicationContext.cacheDir, "upload_${System.nanoTime()}.tmp")
                input.use { source -> FileOutputStream(temp).use { out -> source.copyTo(out) } }
                val plainSize = temp.length(); val digest = sha256(temp)
                val uploadFile = if (key != null) encryptFile(temp, key, rel, File(applicationContext.cacheDir, "enc_${System.nanoTime()}.tmp")) else temp
                val remoteName = if (key != null) safeName + ".waenc" else safeName
                putFile(remote + Uri.encode(remoteName), uploadFile, user, pass, "application/octet-stream")
                records += "file\t${rel.replace("\t", " ")}\t$plainSize\t$digest\t${uploadFile.length()}"
                uploadFile.delete(); if (uploadFile != temp) temp.delete()
                uploaded++
            }
        }
        return uploaded
    }

    private fun ensureCollection(url: String, user: String, pass: String): String {
        val req = Request.Builder().url(url).method("MKCOL", null).header("Authorization", auth(user, pass)).build()
        http.newCall(req).execute().use { if (!it.isSuccessful && it.code != 405) throw Exception("Create folder failed: HTTP ${it.code}") }
        return url
    }

    private fun putFile(url: String, file: File, user: String, pass: String, mime: String) {
        val req = Request.Builder().url(url).put(file.asRequestBody(mime.toMediaType())).header("Authorization", auth(user, pass)).build()
        http.newCall(req).execute().use { if (!it.isSuccessful) throw Exception("Upload failed: HTTP ${it.code}") }
    }

    private fun deriveKey(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 210_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun encryptFile(input: File, keyBytes: ByteArray, relativePath: String, output: File): File {
        val iv = ByteArray(12).also(SecureRandom()::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, javax.crypto.spec.SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(relativePath.toByteArray(Charsets.UTF_8))
        FileOutputStream(output).use { out ->
            out.write("WANC1".toByteArray(Charsets.US_ASCII)); out.write(iv)
            javax.crypto.CipherOutputStream(out, cipher).use { encrypted -> FileInputStream(input).use { it.copyTo(encrypted) } }
        }
        return output
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; md.update(buffer, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
    private fun auth(user: String, pass: String) = "Basic " + android.util.Base64.encodeToString("$user:$pass".toByteArray(), android.util.Base64.NO_WRAP)
}
