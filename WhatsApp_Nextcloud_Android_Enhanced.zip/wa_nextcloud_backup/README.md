# WhatsApp → Nextcloud Android backup (prototype)

Android Studio / Kotlin / Jetpack Compose application. It uploads the contents of a folder granted through Android's Storage Access Framework to a Nextcloud WebDAV directory. Each backup is placed in a timestamped snapshot directory.

## Features in this prototype
- Scheduled WorkManager backup (1–24 hour interval; Android WorkManager periodic minimum is 15 minutes)
- Wi-Fi/unmetered-only or any connected network setting
- One-time manual backup
- Nextcloud WebDAV upload with MKCOL + PUT
- App-password credentials encrypted using Android EncryptedSharedPreferences
- Optional AES-256-GCM per-file encryption, PBKDF2-HMAC-SHA256 (210,000 iterations) key derivation, random 16-byte salt per snapshot, 12-byte IV per file, authenticated relative path as AAD
- Snapshot directory naming, SHA-256 manifest, basic last-success/error status

## Build
1. Open the `wa_nextcloud_backup` directory in Android Studio.
2. Use JDK 17 and allow Gradle sync.
3. Install/run on an Android device.
4. Select the WhatsApp directory through the folder chooser. Choose the directory that contains `Databases` and `Media`, if the Android picker permits it.
5. Enter your Nextcloud HTTPS server URL, username, and a Nextcloud app password. The remote directory is relative to your account's WebDAV root.
6. Save settings, then test with **Back up now**.

## Remote layout
`Backups/WhatsApp/snapshot_YYYY-MM-DD_HH-mm-ss/`

Source directory structure is retained. When encryption is enabled, uploaded file names receive `.waenc` and the manifest is `manifest.tsv.enc`. The encrypted file format is `WANC1` + 12-byte IV + AES-GCM ciphertext/tag. The relative source path is authenticated as AES-GCM AAD. Manifest contains salt and per-file plaintext size, SHA-256, and encrypted size; encrypted manifest uses AAD `manifest`. When encryption is enabled, a plaintext `salt.txt` sidecar is also uploaded so a restore utility can derive the key (the salt is not secret).

## Security and limitations
- Do not lose the encryption password; this prototype has no restore/decryption UI yet.
- Encryption protects file contents, but directory names and snapshot timestamps remain visible in Nextcloud.
- This app cannot read WhatsApp's private app database or decrypt WhatsApp cryptographic backups. It copies files exposed by the folder permission you grant.
- Android/OEM restrictions may block access to `Android/media/com.whatsapp` or particular subfolders. Verify the selected folder and the backup contents on your device.
- WorkManager schedules are inexact and can be delayed by Android battery optimization, device idle, or network conditions. A backup can be manually triggered.
- This prototype has not been compiled or device-tested in this environment. Treat it as development source, not a production-ready backup tool. Review/test before trusting it with irreplaceable data.
- Retention cleanup, restore flow, resumable uploads, deduplication, upload progress, server-side checksum verification, and a WebDAV connection test are not implemented yet.

## Restore (new in 0.2)

The Restore panel accepts a snapshot folder name (for example `snapshot_2026-11-17_22-00-00`) located inside the configured remote folder and a SAF destination folder. It downloads files and decrypts `.waenc` files using the same password and relative-path authenticated data used by the backup worker. It skips snapshot metadata (`manifest*`, `salt.txt`). It does not delete destination files, but files with matching names are overwritten. Make a copy of your current WhatsApp folder first.

Restore runs as a separate one-time WorkManager job and is never triggered by the backup schedule. Select the WhatsApp root directory as destination to recreate its subfolders, or select a narrower destination folder if restoring only a particular tree. Do not restore while WhatsApp is actively using the files. For a database restore, Android/WhatsApp may require force-stopping WhatsApp and restarting it after the files are copied; restore behavior and database compatibility must be tested with the exact WhatsApp release/device.

### Limitations / testing needed

- This source is a development build, not a signed APK. It has not been compiled or device-tested in this environment.
- Android SAF access to `Android/media/com.whatsapp/WhatsApp` varies by OS/device. Verify that the granted directory includes `Databases` and the media folders you intend to protect.
- Restore snapshot selection is manual: enter the folder name. Browse it in Nextcloud first.
- Snapshot manifest is informational; restore currently traverses the WebDAV folder contents and does not verify manifest hashes before writing.
- Restore may overwrite same-name files but does not remove other destination content. Always test with a spare folder first.
- For encrypted snapshots, keep the password securely elsewhere. Losing it makes those files unrecoverable.
- For very large media collections, allow the job to run on reliable Wi-Fi with sufficient free local cache space.

## Build APK using GitHub Actions (no Android SDK needed locally)

1. Create a GitHub repository and upload this project folder to it.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`/`master`).
4. When the workflow succeeds, open the completed run and download the artifact named `WhatsApp-Nextcloud-Backup-debug-apk`.
5. Extract `app-debug.apk`, copy it to your Android phone, and install it. Android may ask you to allow installation from that source.

This workflow builds a debug APK, not a Play Store release. The source project has not yet been compiled or device-tested in this environment. Treat restore as experimental until tested with a non-live destination folder.
